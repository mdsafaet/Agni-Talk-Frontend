import QRCode from './QRCode'
import { IconAndroid, IconApple } from '../icons/Icons'
import { bn, display } from '../../utils/lang'

const badge = { background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255,255,255,0.2)', padding: '14px 24px' }

export default function FinalCTA({ lang }) {
  return (
    <section id="download" style={{ background: '#003366', padding: '80px 0' }}>
      <div className="mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
        <div className="text-center lg:text-left">
          <h2 className={`font-bold text-white mb-4 ${bn(lang)}`} style={{ ...display(lang), fontSize: 'clamp(26px, 5vw, 44px)' }}>
            {lang === 'bn' ? 'ফোন বিলে ছাড় পেতে প্রস্তুত?' : 'Ready to Cut Your Phone Bills?'}
          </h2>
          <p className={`text-white/90 text-lg mb-8 max-w-xl mx-auto lg:mx-0 ${bn(lang)}`}>
            {lang === 'bn'
              ? 'আজই AgniTalk ডাউনলোড করুন এবং আপনার নিজস্ব ০৯৬০৬ নম্বর সহ বিনামূল্যে HD কলিং উপভোগ করুন।'
              : "Download AgniTalk today and enjoy free HD calling with your own 09606 number. Bangladesh's smartest calling app."}
          </p>

          <div className="flex flex-wrap gap-4 justify-center lg:justify-start mb-8">
            <a href="#" className="store-badge" style={badge}>
              <IconAndroid />
              <div>
                <div style={{ fontSize: '10px', opacity: 0.7 }}>GET IT ON</div>
                <div className="font-bold text-base">Google Play</div>
              </div>
            </a>
            <a href="#" className="store-badge" style={badge}>
              <IconApple />
              <div>
                <div style={{ fontSize: '10px', opacity: 0.7 }}>Download on the</div>
                <div className="font-bold text-base">App Store</div>
              </div>
            </a>
          </div>

          <div className="flex flex-col items-center gap-4 sm:flex-row lg:justify-start justify-center">
            <QRCode size={104} caption="" />
            <p className={`text-white/70 text-sm max-w-[220px] sm:text-left ${bn(lang)}`}>
              {lang === 'bn' ? 'ফোনের ক্যামেরা দিয়ে স্ক্যান করে সরাসরি ডাউনলোড করুন' : 'Scan with your phone camera to download instantly'}
            </p>
          </div>
        </div>

        <div className="flex justify-center lg:justify-end">
          <img
            src="/images/campaign.webp"
            alt="AgniTalk campaign poster: a hand holding a phone showing the Agni number screen, with a Download button"
            width="1000"
            height="1000"
            loading="lazy"
            draggable={false}
            className="h-auto w-full max-w-[460px] rounded-2xl"
            style={{ boxShadow: '0 0 0 1px rgba(255,255,255,0.12)' }}
          />
        </div>
      </div>
    </section>
  )
}
