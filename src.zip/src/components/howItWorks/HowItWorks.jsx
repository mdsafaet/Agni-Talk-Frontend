import { FiCreditCard, FiDownload, FiLock, FiMapPin, FiPhoneCall } from 'react-icons/fi'
import { FaIdCard } from 'react-icons/fa'
import { bn, display } from '../../utils/lang'

const STEPS = [
  {
    num: '01',
    Icon: FiDownload,
    en: { title: 'Download AgniTalk', desc: 'Install AgniTalk from Google Play Store, Apple App Store, or download the APK directly for Android devices.' },
    bn: { title: 'AgniTalk ডাউনলোড করুন', desc: 'Google Play Store, Apple App Store থেকে AgniTalk ইনস্টল করুন অথবা সরাসরি APK ডাউনলোড করুন।' },
  },
  {
    num: '02',
    Icon: FaIdCard,
    en: { title: 'Verify Your NID', desc: 'Submit your National ID (NID) via our secure Porichoy API integration. BTRC-mandated verification completes in under 2 minutes.' },
    bn: { title: 'NID যাচাই করুন', desc: 'Porichoy API-এর মাধ্যমে আপনার জাতীয় পরিচয়পত্র (NID) যাচাই করুন। ২ মিনিটেরও কম সময়ে সম্পন্ন হয়।' },
  },
  {
    num: '03',
    Icon: FiPhoneCall,
    en: { title: 'Get Your 09606 Number', desc: "Instantly receive your dedicated virtual IPTSP number with the 09606 prefix, auto-matched to your mobile number's last digits." },
    bn: { title: '০৯৬০৬ নম্বর পান', desc: 'স্বয়ংক্রিয়ভাবে একটি ডেডিকেটেড ভার্চুয়াল IPTSP নম্বর পান যা আপনার মোবাইল নম্বরের শেষ ডিজিটের সাথে মিলে।' },
  },
  {
    num: '04',
    Icon: FiCreditCard,
    en: { title: 'Top Up & Start Calling', desc: 'Recharge via bKash, Nagad, or card in seconds. Make cheap calls to any number in Bangladesh or internationally right away.' },
    bn: { title: 'রিচার্জ করে কল শুরু করুন', desc: 'বিকাশ, নগদ বা কার্ড দিয়ে সেকেন্ডেই রিচার্জ করুন এবং বাংলাদেশ বা বিশ্বের যেকোনো নম্বরে কল শুরু করুন।' },
  },
]

export default function HowItWorks({ lang }) {
  return (
    <section id="how-it-works" style={{ background: '#F8F9FA', padding: '80px 0' }}>
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className={`font-bold mb-3 ${bn(lang)}`} style={{ ...display(lang), fontSize: 'clamp(24px, 4vw, 36px)', color: '#003366' }}>
            {lang === 'bn' ? 'মাত্র ৪টি ধাপে শুরু করুন' : 'Up & Running in 4 Simple Steps'}
          </h2>
          <p className={`text-gray-500 max-w-xl mx-auto ${bn(lang)}`}>
            {lang === 'bn'
              ? 'NID যাচাই থেকে শুরু করে প্রথম কল পর্যন্ত — সব কিছু সহজ।'
              : 'From NID verification to your first call — everything is designed to be effortless.'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {STEPS.map((s, i) => {
            const t = lang === 'bn' ? s.bn : s.en
            return (
              <div key={i} className="relative">
                <div className="card p-6">
                  <div className="flex items-center justify-between mb-4">
                    <s.Icon className="text-3xl" />
                    <span className="font-bold text-5xl" style={{ fontFamily: 'var(--agni-display)', color: 'rgba(0,51,102,0.08)' }}>{s.num}</span>
                  </div>
                  <h3 className={`font-bold mb-2 ${bn(lang)}`} style={{ ...display(lang), color: '#003366' }}>{t.title}</h3>
                  <p className={`text-sm text-gray-500 leading-relaxed ${bn(lang)}`}>{t.desc}</p>
                </div>
                {i < STEPS.length - 1 && (
                  <div
                    className="hidden lg:flex absolute top-1/2 -right-3 z-10 items-center justify-center w-6 h-6 rounded-full"
                    style={{ background: '#FF5722', transform: 'translateY(-50%)' }}
                  >
                    <span className="text-white text-xs">→</span>
                  </div>
                )}
              </div>
            )
          })}
        </div>

        {/* NID / GPS notices */}
        <div className="mt-10 grid grid-cols-1 lg:grid-cols-5 gap-6">
          <div className="card lg:col-span-2 flex items-center justify-center p-6">
            <img
              src="/images/phones-register-call.webp"
              alt="AgniTalk registration screen next to an active call screen"
              width="728"
              height="809"
              loading="lazy"
              draggable={false}
              className="h-auto w-full max-w-[300px]"
            />
          </div>
          <div className="lg:col-span-3 flex flex-col justify-center gap-4">
            <div className="rounded-xl p-4 flex gap-3" style={{ background: 'rgba(0,51,102,0.04)', border: '1px solid rgba(0,51,102,0.1)' }}>
              <FiLock className="text-xl flex-shrink-0 mt-0.5" style={{ color: '#003366' }} />
              <div>
                <div className={`font-semibold text-sm mb-1 ${bn(lang)}`} style={{ ...display(lang), color: '#003366' }}>
                  {lang === 'bn' ? 'কেন NID প্রয়োজন?' : 'Why is NID Required?'}
                </div>
                <p className={`text-xs text-gray-500 ${bn(lang)}`}>
                  {lang === 'bn'
                    ? 'BTRC-এর বিধিমালা অনুযায়ী ০৯৬০৬ ভার্চুয়াল নম্বর সক্রিয় করতে NID যাচাই বাধ্যতামূলক। আপনার তথ্য Porichoy API-এ এনক্রিপ্টেড আকারে পাঠানো হয়।'
                    : "NID verification is required by BTRC regulations to activate your 09606 virtual number. Your data is encrypted and verified directly via Bangladesh EC's Porichoy API — never stored locally."}
                </p>
              </div>
            </div>
            <div className="rounded-xl p-4 flex gap-3" style={{ background: 'rgba(255,87,34,0.04)', border: '1px solid rgba(255,87,34,0.1)' }}>
              <FiMapPin className="text-xl flex-shrink-0 mt-0.5" style={{ color: '#0052CC' }} />
              <div>
                <div className={`font-semibold text-sm mb-1 ${bn(lang)}`} style={{ ...display(lang), color: '#0052CC' }}>
                  {lang === 'bn' ? 'GPS অনুমতি কেন?' : 'Why GPS Location Permission?'}
                </div>
                <p className={`text-xs text-gray-500 ${bn(lang)}`}>
                  {lang === 'bn'
                    ? 'টেলিযোগাযোগ আইন অনুযায়ী নিবন্ধনের সময় একবার GPS অনুমতি প্রয়োজন যা নিশ্চিত করে আপনি বাংলাদেশে আছেন।'
                    : 'GPS location permission is required once during registration to confirm you are within Bangladesh as per telecom regulations. Location is not tracked continuously.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
